This plunk uses open layers 3 and shows how you can use a polygon from ol.interaction.Draw to create 
an area which will select all point features contained in it.

[There is a walkthrough for the code on my blog](http://dafyddprys.github.io/2016/02/10/select-features-in-openLayers-using-polygon-draw.html)